// ==========================================================================
// ASTROLIFE - ASTRONAUT PROFILE ONBOARDING & PERSISTENCE
// ==========================================================================

document.addEventListener("DOMContentLoaded", function () {
    const profileForm = document.getElementById("profileForm");
    const photoInput = document.getElementById("profilePhoto");
    const photoPreview = document.getElementById("photoPreview");
    const formMessage = document.getElementById("formMessage");
    const profileSummary = document.getElementById("profileSummary");
    const summaryContent = document.getElementById("summaryContent");
    const editProfileBtn = document.getElementById("editProfile");
    const continueBtn = document.getElementById("continueBtn");

    let astronautProfile = null;
    let savedPhotoData = null;

    // Helper to get trimmed input value
    function getValue(id) {
        const el = document.getElementById(id);
        return el ? el.value.trim() : "";
    }

    // Helper to set input value
    function setValue(id, val) {
        const el = document.getElementById(id);
        if (el && val !== undefined && val !== null) {
            el.value = val;
        }
    }

    // 1. Profile photo preview using FileReader (persists preview reliably)
    if (photoInput) {
        photoInput.addEventListener("change", function () {
            const file = this.files[0];
            if (!file) return;

            if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
                alert("Please select a JPG, PNG or WebP image.");
                this.value = "";
                return;
            }

            if (file.size > 5 * 1024 * 1024) {
                alert("Image size must be less than 5 MB.");
                this.value = "";
                return;
            }

            const reader = new FileReader();
            reader.onload = function (e) {
                savedPhotoData = e.target.result;
                displayPhoto(savedPhotoData);
            };
            reader.readAsDataURL(file);
        });
    }

    function displayPhoto(src) {
        if (!photoPreview || !src) return;
        photoPreview.innerHTML = "";
        const image = document.createElement("img");
        image.src = src;
        image.alt = "Astronaut profile preview";
        photoPreview.appendChild(image);
    }

    // 2. Display profile summary safely
    function showProfileSummary() {
        if (!astronautProfile || !summaryContent || !profileSummary) return;

        const fields = [
            ["Full Name", astronautProfile.name],
            ["Age", astronautProfile.age],
            ["Gender", astronautProfile.gender],
            ["Blood Group", astronautProfile.bloodGroup],
            ["Height", astronautProfile.height ? astronautProfile.height + " cm" : ""],
            ["Weight", astronautProfile.weight ? astronautProfile.weight + " kg" : ""],
            ["Medical History", astronautProfile.medicalHistory],
            ["Allergies", astronautProfile.allergies],
            ["Emergency Contact", astronautProfile.emergencyName],
            ["Emergency Phone", astronautProfile.emergencyPhone],
            ["Relationship", astronautProfile.relationship],
            ["Mission Name", astronautProfile.missionName],
            ["Launch Date", astronautProfile.launchDate],
            ["Mission Duration", astronautProfile.missionDuration ? astronautProfile.missionDuration + " days" : ""]
        ];

        summaryContent.replaceChildren();

        fields.forEach(function ([label, value]) {
            if (!value) return;

            const item = document.createElement("div");
            item.className = "summary-item";

            const strong = document.createElement("strong");
            strong.textContent = label + ": ";

            item.appendChild(strong);
            item.appendChild(document.createTextNode(value));

            summaryContent.appendChild(item);
        });

        profileSummary.hidden = false;
    }

    // 3. Save profile form
    if (profileForm) {
        profileForm.addEventListener("submit", function (event) {
            event.preventDefault();

            const age = Number(getValue("age"));
            const phone = getValue("emergencyPhone");

            if (age < 18 || age > 100) {
                if (formMessage) formMessage.textContent = "Please enter a valid age (18 - 100).";
                return;
            }

            if (!/^\+?[0-9\s()-]{7,20}$/.test(phone)) {
                if (formMessage) formMessage.textContent = "Please enter a valid emergency phone number.";
                return;
            }

            astronautProfile = {
                name: getValue("fullName"),
                age: getValue("age"),
                gender: getValue("gender"),
                bloodGroup: getValue("bloodGroup"),
                height: getValue("height"),
                weight: getValue("weight"),
                medicalHistory: getValue("medicalHistory"),
                allergies: getValue("allergies"),
                emergencyName: getValue("emergencyName"),
                emergencyPhone: phone,
                relationship: getValue("relationship"),
                missionName: getValue("missionName"),
                launchDate: getValue("launchDate"),
                missionDuration: getValue("missionDuration"),
                photo: savedPhotoData
            };

            // Save to localStorage & update active user session
            localStorage.setItem("astronaut_profile", JSON.stringify(astronautProfile));
            if (astronautProfile.name) {
                sessionStorage.setItem("astro_user", astronautProfile.name);
            }

            showProfileSummary();
            if (formMessage) {
                formMessage.textContent = "Astronaut profile saved successfully!";
            }
            profileSummary.scrollIntoView({ behavior: "smooth" });
        });
    }

    // 4. Edit profile button
    if (editProfileBtn) {
        editProfileBtn.addEventListener("click", function () {
            if (profileSummary) profileSummary.hidden = true;
            if (profileForm) profileForm.scrollIntoView({ behavior: "smooth" });
        });
    }

    // 5. Continue to Dashboard button
    if (continueBtn) {
        continueBtn.addEventListener("click", function () {
            if (astronautProfile) {
                localStorage.setItem("astronaut_profile", JSON.stringify(astronautProfile));
                if (astronautProfile.name) {
                    sessionStorage.setItem("astro_user", astronautProfile.name);
                }
            }
            window.location.href = "dashboard.html";
        });
    }

    // 6. INITIAL LOAD: Pre-fill from existing profile or user session
    const savedProfileJson = localStorage.getItem("astronaut_profile");
    if (savedProfileJson) {
        try {
            astronautProfile = JSON.parse(savedProfileJson);
            if (astronautProfile) {
                setValue("fullName", astronautProfile.name);
                setValue("age", astronautProfile.age);
                setValue("gender", astronautProfile.gender);
                setValue("bloodGroup", astronautProfile.bloodGroup);
                setValue("height", astronautProfile.height);
                setValue("weight", astronautProfile.weight);
                setValue("medicalHistory", astronautProfile.medicalHistory);
                setValue("allergies", astronautProfile.allergies);
                setValue("emergencyName", astronautProfile.emergencyName);
                setValue("emergencyPhone", astronautProfile.emergencyPhone);
                setValue("relationship", astronautProfile.relationship);
                setValue("missionName", astronautProfile.missionName);
                setValue("launchDate", astronautProfile.launchDate);
                setValue("missionDuration", astronautProfile.missionDuration);

                if (astronautProfile.photo) {
                    savedPhotoData = astronautProfile.photo;
                    displayPhoto(savedPhotoData);
                }

                showProfileSummary();
            }
        } catch (err) {
            console.error("Error parsing saved astronaut profile:", err);
        }
    } else {
        // Pre-fill name from session if available
        const sessionUser = sessionStorage.getItem("astro_user");
        if (sessionUser && sessionUser !== "Commander") {
            setValue("fullName", sessionUser);
        }
    }
});
